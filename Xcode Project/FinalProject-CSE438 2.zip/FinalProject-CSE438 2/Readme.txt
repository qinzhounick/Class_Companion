What's been done:

Features implemented:
	Conversation History with search.
	Windows for Trnascript, Q&A + Model Thoughts.
	Windows are Integrated temporarily with OpenAi.
	Chats names are editable, storage via core data.

Features Pending:
	Microphone for Live Transcript
	Integration with Backend.
	UI Overhaul


Nessim Yohros, Joseph Islam, Jiayu Huang